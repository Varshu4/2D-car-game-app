package com.example.carapplication

interface GameTask {
    fun closeGame(mScore:Int)
}